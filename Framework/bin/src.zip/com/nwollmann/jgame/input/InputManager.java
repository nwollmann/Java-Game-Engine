package com.nwollmann.jgame.input;

import java.util.ArrayList;

public class InputManager {
	//has queue for input
	ArrayList<GameInput> inputListeners;
	
}
