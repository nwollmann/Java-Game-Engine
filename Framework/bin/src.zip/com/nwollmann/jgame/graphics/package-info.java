/**
 * Renderers and other components related to graphics.
 */
package com.nwollmann.jgame.graphics;