package com.nwollmann.jgame.graphics;

import javax.swing.JPanel;

/**
 * Not currently doing anything. Functionality will probably be added at some point in the future.
 * @author Nicholas Wollmann
 *
 */
public class GamePanel extends JPanel{

	/**
	 * 
	 */
	private static final long serialVersionUID = -5991445280023118485L;

}
