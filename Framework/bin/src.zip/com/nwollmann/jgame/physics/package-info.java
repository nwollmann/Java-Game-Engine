/**
 * Components related to physics such as colliders.
 */
package com.nwollmann.jgame.physics;