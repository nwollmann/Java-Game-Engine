/**
 * Various exceptions that the engine can throw during execution.
 */
package com.nwollmann.jgame.exceptions;

