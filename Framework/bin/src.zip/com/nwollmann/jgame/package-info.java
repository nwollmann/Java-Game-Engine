/**
 * The core components of the game engine.
 */
package com.nwollmann.jgame;