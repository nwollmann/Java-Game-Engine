package flappyStarter;
import com.nwollmann.jgame.input.GameInput;
public class InputListener implements GameInput{
	@Override
	public void keyPressed(int keyID){
		//put code to accept input here
	}
}
