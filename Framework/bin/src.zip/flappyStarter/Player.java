package flappyStarter;
import com.nwollmann.jgame.util.GameObject;
public class Player extends GameObject{
	
	public Player(){
		super();
		//other setup here
	}
	
	@Override
	public void update(){
		//will be called every update interval (default of 15ms)
	}
}
